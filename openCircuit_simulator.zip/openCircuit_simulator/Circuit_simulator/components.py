class Resistor:
    def __init__(self, resistance):
        self.resistance = resistance

class Capacitor:
    def __init__(self, capacitance):
        self.capacitance = capacitance

class Inductor:
    def __init__(self, inductance):
        self.inductance = inductance

class VoltageSource:
    def __init__(self, voltage):
        self.voltage = voltage
