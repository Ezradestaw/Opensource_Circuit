def thevenin_theorem(resistor, voltage_source):
    # Thevenin equivalent voltage and resistance
    pass

def norton_theorem(resistor, current_source):
    # Norton equivalent current and resistance
    pass

def source_transformation(voltage_source, resistor):
    # Convert voltage source + resistor to current source
    pass
