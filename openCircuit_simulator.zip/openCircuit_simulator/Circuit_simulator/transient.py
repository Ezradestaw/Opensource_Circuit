from scipy.integrate import odeint

def capacitor_transient(initial_voltage, resistance, capacitance, time_points):
    def dVdt(V, t):
        return (1 / (resistance * capacitance)) * (initial_voltage - V)

    return odeint(dVdt, initial_voltage, time_points)
