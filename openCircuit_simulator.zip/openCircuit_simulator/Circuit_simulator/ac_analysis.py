import matplotlib.pyplot as plt
import numpy as np

def ac_circuit_analysis(frequency, amplitude, time_points):
    # Simulate an AC signal (sinusoidal)
    voltage = amplitude * np.sin(2 * np.pi * frequency * time_points)
    plt.plot(time_points, voltage)
    plt.title("AC Voltage Waveform")
    plt.xlabel("Time (s)")
    plt.ylabel("Voltage (V)")
    plt.show()
