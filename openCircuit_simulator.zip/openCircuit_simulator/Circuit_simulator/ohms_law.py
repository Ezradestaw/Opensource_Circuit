def ohms_law(voltage, resistance):
    return voltage / resistance
