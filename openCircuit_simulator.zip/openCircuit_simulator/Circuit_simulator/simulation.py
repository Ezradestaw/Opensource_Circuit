from .circuit import Circuit
from .components import Resistor, Capacitor, VoltageSource
from .ohms_law import ohms_law
from .kirchhoff import kirchhoff_voltage_law
from .transient import capacitor_transient

def run_simulation():
    # Example of setting up a simple circuit
    circuit = Circuit()
    resistor = Resistor(10)  # 10 ohms
    capacitor = Capacitor(0.1)  # 0.1 F
    voltage_source = VoltageSource(12)  # 12 V

    circuit.add_component(resistor)
    circuit.add_component(capacitor)
    circuit.add_component(voltage_source)

    # Calculate current using Ohm's law (for example)
    current = ohms_law(voltage_source.voltage, resistor.resistance)
    print(f"Current in the circuit: {current} A")

    # Transient analysis for capacitor
    time_points = np.linspace(0, 10, 1000)  # 10 seconds, 1000 points
    capacitor_voltage = capacitor_transient(12, resistor.resistance, capacitor.capacitance, time_points)
    print("Capacitor transient:", capacitor_voltage)
