def kirchhoff_voltage_law(voltage_sources, voltage_drops):
    return sum(voltage_sources) - sum(voltage_drops)

def kirchhoff_current_law(currents):
    return sum(currents)  # Should be zero for a closed node
