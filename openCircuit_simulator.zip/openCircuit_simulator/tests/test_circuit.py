import unittest
from circuit_simulator.circuit import Circuit
from circuit_simulator.components import Resistor

class TestCircuit(unittest.TestCase):

    def test_add_component(self):
        circuit = Circuit()
        r = Resistor(10)
        circuit.add_component(r)
        self.assertIn(r, circuit.components)

if __name__ == '__main__':
    unittest.main()
