import unittest
from circuit_simulator.components import Resistor, Capacitor, Inductor, VoltageSource

class TestComponents(unittest.TestCase):

    def test_resistor(self):
        r = Resistor(10)
        self.assertEqual(r.resistance, 10)

    def test_capacitor(self):
        c = Capacitor(0.1)
        self.assertEqual(c.capacitance, 0.1)

    def test_inductor(self):
        l = Inductor(2)
        self.assertEqual(l.inductance, 2)

    def test_voltage_source(self):
        v = VoltageSource(12)
        self.assertEqual(v.voltage, 12)

if __name__ == '__main__':
    unittest.main()
