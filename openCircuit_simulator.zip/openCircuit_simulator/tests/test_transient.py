import unittest
import numpy as np
from circuit_simulator.transient import capacitor_transient

class TestTransient(unittest.TestCase):

    def test_capacitor_transient(self):
        time_points = np.linspace(0, 1, 10)
        result = capacitor_transient(5, 10, 0.1, time_points)
        self.assertEqual(result.shape[0], len(time_points))

if __name__ == '__main__':
    unittest.main()
